import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { UsersettingsPage } from '../usersettings/usersettings';
import { HomePage } from '../home/home';


@Component({
  selector: 'page-home1',
  templateUrl: 'home1.html',
})
export class Home1Page {
  
  event: { month: string; timeStarts: string; timeEnds: string; };
 
  event1: { month: string; timeStarts: string; timeEnds: string; };
  event2: { month: string; timeStarts: string; timeEnds: string; };
  event3: { month: string; timeStarts: string; timeEnds: string; };
  event4: { month: string; timeStarts: string; timeEnds: string; };

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.fetchtime();
   }
   
  fetchtime()
  {
    this.event = {
      month: '1990-02-19',
      timeStarts: '04:23',
      timeEnds: '1990-02-20'
    }
   this.event1 = {
      month: '1990-02-19',
      timeStarts: '01:13',
      timeEnds: '1990-02-20'
    }
    this.event2 = {
      month: '1990-02-19',
      timeStarts: '04:15',
      timeEnds: '1990-02-20'
    }
    this.event3 = {
      month: '1990-02-19',
      timeStarts: '07:15',
      timeEnds: '1990-02-20'
    }
    this.event4 = {
      month: '1990-02-19',
      timeStarts: '08:45',
      timeEnds: '1990-02-20'
    }
  }
settings()
{

  this.navCtrl.push(UsersettingsPage);
}


}
