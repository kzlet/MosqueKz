import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';


@Component({
  selector: 'page-announcements',
  templateUrl: 'announcements.html',
})
export class AnnouncementsPage {

  constructor(public alertCtrl: AlertController,public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AnnouncementsPage');
  }
  salert()
  {



    const alert = this.alertCtrl.create({
  
      subTitle: 'Your request has been forwarded to admin, once approved it will be posted',
      buttons: ['OK']
    });
    alert.present();
  }
}
