import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';


@Component({
  selector: 'page-mosque',
  templateUrl: 'mosque.html',
})
export class MosquePage {
  value1: any;
  value2: boolean;
  value3: any;
  value4: boolean;

  constructor(public alertCtrl: AlertController,public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MosquePage');
  }

  next()
  {
console.log("ext is called");
console.log("Value1:" + this.value1);

if(this.value1 === true)
{
  const alert = this.alertCtrl.create({
    
    subTitle: 'Do u want to recieve notification from this masjid',
    buttons: ['OK']
  });
  alert.present();
}}
next1(){ 
console.log("Value2:" + this.value2);
if(this.value2 === true)
{
  const alert = this.alertCtrl.create({
    
    subTitle: 'Do u want to recieve notification from this masjid',
    buttons: ['OK']
  });
  alert.present();
}}
next2(){ 
  console.log("Value3:" + this.value3);
  if(this.value3 === true)
  {
    const alert = this.alertCtrl.create({
      
      subTitle: 'Do u want to recieve notification from this masjid',
      buttons: ['OK']
    });
    alert.present();
  }}
  next3(){ 
    console.log("Value2:" + this.value4);
    if(this.value4 === true)
    {
      const alert = this.alertCtrl.create({
        
        subTitle: 'Do u want to recieve notification from this masjid',
        buttons: ['OK']
      });
      alert.present();
    }
}}
