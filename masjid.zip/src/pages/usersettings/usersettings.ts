import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { HomePage } from '../home/home';


@Component({
  selector: 'page-usersettings',
  templateUrl: 'usersettings.html',
})
export class UsersettingsPage {

  constructor(public app: App,public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad UsersettingsPage');
  }
  logout()
  {
   // this.navCtrl.push(HomePage);
    //this.navCtrl.goToRoot();
    this.app.getRootNav().setRoot(HomePage);
  }
}
