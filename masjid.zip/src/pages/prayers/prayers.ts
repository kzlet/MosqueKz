import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@Component({
  selector: 'page-prayers',
  templateUrl: 'prayers.html',
})
export class PrayersPage {
 
  event: { month: string; timeStarts: string; timeEnds: string; };
  event1: { month: string; timeStarts: string; timeEnds: string; };
  event2: { month: string; timeStarts: string; timeEnds: string; };
  event3: { month: string; timeStarts: string; timeEnds: string; };
  event4: { month: string; timeStarts: string; timeEnds: string; };


  constructor(public navCtrl: NavController, public navParams: NavParams) {
   this.fetchtime();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PrayersPage');
  }

  fetchtime()
  {
    this.event = {
      month: '1990-02-19',
      timeStarts: '04:23',
      timeEnds: '1990-02-20'
    }
   this.event1 = {
      month: '1990-02-19',
      timeStarts: '01:13',
      timeEnds: '1990-02-20'
    }
    this.event2 = {
      month: '1990-02-19',
      timeStarts: '04:15',
      timeEnds: '1990-02-20'
    }
    this.event3 = {
      month: '1990-02-19',
      timeStarts: '07:15',
      timeEnds: '1990-02-20'
    }
    this.event4 = {
      month: '1990-02-19',
      timeStarts: '08:45',
      timeEnds: '1990-02-20'
    }
  }

}
