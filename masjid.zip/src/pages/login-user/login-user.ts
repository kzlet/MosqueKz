import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { MosquePage } from '../mosque/mosque';
import { TabuserPage } from '../tabuser/tabuser';

@Component({
  selector: 'page-login-user',
  templateUrl: 'login-user.html',
})
export class LoginUserPage {
  user:string ="login";
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginUserPage');
  }
masjid()
{this.navCtrl.push(MosquePage);

}
tab(){

this.navCtrl.push(TabuserPage);

}
}
