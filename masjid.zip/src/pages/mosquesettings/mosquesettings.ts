import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { HomePage } from '../home/home';


@Component({
  selector: 'page-mosquesettings',
  templateUrl: 'mosquesettings.html',
})
export class MosquesettingsPage {

  constructor(public app: App, public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MosquesettingsPage');
  }


  posts()
  {
    alert("This will display all posts that you have posted so far");
  }

  msg()
  {
    alert("This will display all messages from Administrator");
  }

  profile()
  {
    alert("This will allow you to update profile");
  }

  location()
  {
    alert("This will allow you to update mosque location");
  }

  password()
  {
    alert("This will allow you to change password");
  }

  logout()
  {
   // this.navCtrl.push(HomePage);
    //this.navCtrl.goToRoot();
    this.app.getRootNav().setRoot(HomePage);
  }

}
