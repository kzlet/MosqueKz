import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AnnouncementsPage } from '../announcements/announcements';
import { PrayersPage } from '../prayers/prayers';
import { MorguePage } from '../morgue/morgue';
import { MosquesettingsPage } from '../mosquesettings/mosquesettings';


@Component({
  selector: 'page-mosquelogin',
  templateUrl: 'mosquelogin.html',
})
export class MosqueloginPage {
tab1= AnnouncementsPage;
tab2= PrayersPage;
tab3= MorguePage;
tab4= MosquesettingsPage;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MosqueloginPage');
  }

}
