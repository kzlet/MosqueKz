import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';


@Component({
  selector: 'page-morgue',
  templateUrl: 'morgue.html',
})
export class MorguePage {

  constructor(public alertCtrl: AlertController,public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MorguePage');
  }
  salert()
  {



    const alert = this.alertCtrl.create({
  
      subTitle: 'Your request has been forwarded to admin, once approved it will be posted',
      buttons: ['OK']
    });
    alert.present();
  }

}
