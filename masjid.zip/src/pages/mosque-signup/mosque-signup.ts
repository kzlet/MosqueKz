import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SignupPage } from '../signup/signup';
import { MosqueloginPage } from '../mosquelogin/mosquelogin';

@Component({
  selector: 'page-mosque-signup',
  templateUrl: 'mosque-signup.html',
})
export class MosqueSignupPage {
  User:string ="login";
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MosqueSignupPage');
  }
  signup()
  {
this.navCtrl.push(SignupPage);

  }
tabpage()
{

this.navCtrl.push(MosqueloginPage);

}
}
