import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { MosqueSignupPage } from '../pages/mosque-signup/mosque-signup';
import { SignupPage } from '../pages/signup/signup';
import { LoginUserPage } from '../pages/login-user/login-user';
import { MosqueloginPage } from '../pages/mosquelogin/mosquelogin';
import { PrayersPage } from '../pages/prayers/prayers';
import { AnnouncementsPage } from '../pages/announcements/announcements';
import { MorguePage } from '../pages/morgue/morgue';
import { MosquesettingsPage } from '../pages/mosquesettings/mosquesettings';
import { MosquePage } from '../pages/mosque/mosque';
import { TabuserPage } from '../pages/tabuser/tabuser';
import { Home1Page } from '../pages/home1/home1';
import { NotificationPage } from '../pages/notification/notification';
import { UsersettingsPage } from '../pages/usersettings/usersettings';
import { UsermosquePage } from '../pages/usermosque/usermosque';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    MosqueSignupPage,
    SignupPage,
    LoginUserPage,
    MosqueloginPage,
    PrayersPage,
    AnnouncementsPage,
    MorguePage,
    MosquesettingsPage,MosquePage,TabuserPage,Home1Page,NotificationPage,UsersettingsPage,UsermosquePage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    MosqueSignupPage,
    SignupPage,
    LoginUserPage,
    MosqueloginPage,
    PrayersPage,
    AnnouncementsPage,
    MorguePage,
    MosquesettingsPage,MosquePage,TabuserPage,Home1Page,NotificationPage,UsersettingsPage,UsermosquePage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
